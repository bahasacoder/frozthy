import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  items: [],
};

const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    addToCart: (state, action) => {
      const product = action.payload;
      // Cek apakah produk sudah ada di dalam keranjang
      const existingItem = state.items.find((item) => item.id === product.id);

      if (existingItem) {
        // Jika sudah ada, tambahkan jumlah kuantitasnya
        existingItem.quantity += 1;
      } else {
        // Jika belum ada, masukkan produk baru dengan kuantitas 1
        state.items.push({ ...product, quantity: 1 });
      }
    },
  },
});

export const { addToCart } = cartSlice.actions;
export default cartSlice.reducer;