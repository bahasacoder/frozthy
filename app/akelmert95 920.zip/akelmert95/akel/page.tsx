"use client"
import Image from "next/image";
import Link from 'next/link'
// page
import { useSelector } from 'react-redux';
// components
import { useDispatch } from 'react-redux';

import {addToCart} from '@/lib/features/cartSlice';
import { useAppSelector, useAppDispatch } from '@/lib/hooks';

export default function AkelPage() {
	// page
	const cart = useAppSelector((state) => state.cart)
	const totalQuantity = () => {
	  let total = 0
	  cart.cart.forEach((item:any) => {
		total += item.quantity
	  })
	  return total
	}
	
	// components
	const dispatch = useDispatch()
  return (
  <>
    <div>
		
		<button 
		  onClick={() => 
			dispatch(addToCart({
			  id, title, image, price
			}))
		  }>Add to Cart
		</button>
	</div>
	{/* Page */}
	<Link className='shopping-cart' href={'/akel-cart'}>
		{/* <ShoppingCart id='cartIcon'/> */}
	  <p>{totalQuantity() || 0}</p>
	</Link>
</>

  );
}
