"use client"
import { useSelector } from 'react-redux'
import { useDispatch } from 'react-redux';
import { useAppSelector, useAppDispatch } from '@/lib/hooks';
// import { RootState, AppDispatch, AppStore } from '@/lib/store';

import {addToCart} from '@/lib/features/cartSlice';
import { CartItem } from "./CartItem"
export default function AkelCartPage() {	
  const cart = useAppSelector((state) => state.cart)
  const dispatch = useAppDispatch();
  // const dispatch = useDispatch<AppDispatch>();
  
  return (
	<>
		<h1>Akel Cart Page</h1>
		<div className="cart__left">
			<div>
				<h3>Shopping Cart</h3>
				{cart?.cart?.map((item:any) => (
				<CartItem
					key={item.id}
					id={item.id}
					image={item.image}
					title={item.title}
					price={item.price} 
					quantity={item.quantity}
				/>
				))}
			</div>
			</div>
		
	  
	</>
  )
}