import { useSelector } from 'react-redux'
import { useDispatch } from 'react-redux';
import { useAppSelector, useAppDispatch } from '@/lib/hooks';
import { RootState, AppDispatch, AppStore } from '@/lib/store';

import {addToCart} from '@/lib/features/cartSlice';

export default function AkelCartComponent() {	
  const cart = useAppSelector((state) => state.cart)
  // const dispatch = useAppDispatch();
  const getTotal = () => {
    let totalQuantity = 0
    let totalPrice = 0
    cart.cart.forEach(item => {
      totalQuantity += item.quantity
      totalPrice += item.price * item.quantity
    })
    return {totalPrice, totalQuantity}
  }
  
  return (
	<>
	<h1>Total Cart</h1>
  <p className="total__p">
    total ({getTotal().totalQuantity} items) 
    : <strong>${getTotal().totalPrice}</strong>
  </p>
	  
	</>
  )
}